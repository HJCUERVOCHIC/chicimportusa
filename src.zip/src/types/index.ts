// Tipos para el modelo de datos de ChicImportUSA

export type PublicacionStatus = 'active' | 'closed'
export type ProductStatus = 'available' | 'closed'

export interface Product {
  id: string
  name: string
  brand: string
  category: string
  image: string
  price_ref: string
  status: ProductStatus
}

export interface Publicacion {
  id: string
  title: string
  date: string
  status: PublicacionStatus
  products: Product[]
}

export interface PublicacionesData {
  publicaciones: Publicacion[]
}

// Tipos para testimonios
export interface Testimonial {
  id: string
  name: string
  location: string
  text: string
  product?: string
}

// Constantes
export const WHATSAPP_LINK = 'https://chat.whatsapp.com/KXwhlBpFKeh8521CBRvJp6'
export const WHATSAPP_CTA_TEXT = 'Unirme al WhatsApp'
